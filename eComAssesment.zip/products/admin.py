from django.contrib import admin
from .models import Products
from . import models
# Register your models here.
admin.site.register(Products)
